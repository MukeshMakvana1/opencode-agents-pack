# Opencode 100+ Advanced Agents Pack

[![GitHub stars](https://img.shields.io/github/stars/MukeshMakvana1/opencode-agents-pack?style=social)](https://github.com/MukeshMakvana1/opencode-agents-pack) [![GitHub forks](https://img.shields.io/github/forks/MukeshMakvana1/opencode-agents-pack)](https://github.com/MukeshMakvana1/opencode-agents-pack) [![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

## 🎯 Introduction

**Opencode Agents Pack** - **37 specialized AI agents** (700+ skills) for [Opencode](https://opencode.ai) terminal. Domain experts ready to code.

## 📦 Windows Installation (5 minutes)

### Step 1: Download & Extract
```
1. Download opencode-agents-pack.zip from:
   https://github.com/MukeshMakvana1/opencode-agents-pack/releases
   
2. Extract ALL to: C:\\Users\\[YourName]\\.opencode\\agents\\
   (Creates agents/devops/, agents/mobile/, etc.)
```

### Step 2: Verify
```
dir "%USERPROFILE%\.opencode\agents"
# Should show: devops, security, mobile, etc.
```

### Step 3: Launch Opencode
```
opencode
```

Agents auto-discovered! 🎉

## 🚀 How to Use (Examples)

### Agent Commands
```
# Activate agent (prefix @)
@mobile-react-native-dev build shopping app
@devops-kubernetes-expert deploy microservices cluster
@security-penetration-tester OWASP Top 10 audit localhost:3000

# List all agents
agent

# Cycle agents
agent.cycle

# Custom model
opencode --model opencode/minimax-m2.5-free
```

### Real-World Examples
**1. React Native App**
```
@mobile-react-native-dev
Create e-commerce app with Stripe payments, push notifications, offline cart
```

**2. Kubernetes Cluster**
```
@devops-kubernetes-expert
Production Postgres deployment with auto-scaling, monitoring, secrets
```

**3. Security Audit**
```
@security-cybersec-analyst
SIEM dashboard for AWS CloudTrail logs + threat hunting queries
```

## 🗂️ Full Agent List (37 Agents)

### DevOps (5)
- kubernetes-expert.md
- docker-master.md
- cicd-pro.md
- cloud-architect-aws.md
- terraform-specialist.md

### Security (5)
- penetration-tester.md
- cybersec-analyst.md
- crypto-expert.md
- firewall-engineer.md
- incident-responder.md

### Data Science (5)
- pandas-pro.md
- spark-engineer.md
- tableau-viz-master.md
- etl-designer.md
- feature-engineer.md

### Blockchain (5)
- solidity-dev.md
- web3-expert.md
- smart-contract-auditor.md
- defi-architect.md
- nft-creator.md

### Game Development (5)
- unity-expert.md
- unreal-engine-pro.md
- godot-dev.md
- game-ai.md
- multiplayer-netcode.md

### Mobile (5)
- react-native-dev.md
- flutter-expert.md
- swift-ios.md
- kotlin-android.md
- cross-platform-master.md

### Core (7)
- web-developer.md | ai-developer.md | python-developer.md | pc-control.md
- video-transcriber.md | code-runner.md | bug-fixer.md

**Total Skills: 700+** (25+ per agent)

## ⚙️ Agent Template (All Validated)
```
---
name: [name]
mode: all
model: opencode/minimax-m2.5-free
tools: [write, bash, read...]
---
[25+ domain skills]
```

## 🔧 Troubleshooting

| Issue | Solution |
|-------|----------|
| Model invalid | `opencode models` → copy exact ID |
| No agents | Check `%USERPROFILE%\.opencode\agents` |
| YAML error | 2-space indent, no tabs |
| Slow | Use `opencode/gpt-5-nano` |

**Debug Mode:**
```
opencode --log-level DEBUG
```

## 📱 Quick Start Video Tutorial
*(Add your demo video here)*

## 🤝 Contribute
1. Fork https://github.com/MukeshMakvana1/opencode-agents-pack
2. Add `new-category/new-agent.md`
3. PR → [Create PR](https://github.com/MukeshMakvana1/opencode-agents-pack/compare)

## 📄 License
[MIT](LICENSE) © Mukesh Kumar Makwana

## ⭐ Support
⭐ Star | 🍴 Fork | 🐛 Issues | 💬 Discussions

**Upload this folder to your GitHub repo - instant sharing!**

