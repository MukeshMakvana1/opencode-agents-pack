---
name: code-debugging
description: Bug fixing, debugging, error resolution, code troubleshooting
origin: custom-agent
---

# Debugging & Bug Fixing Skill

Use this skill when fixing bugs, debugging code, or troubleshooting errors.

## When to Activate
- Code has errors or bugs
- Application crashes
- Unexpected behavior
- Performance issues
- Code quality improvements needed

## Debugging Process

### 1. Identify the Problem
```bash
# Run code to see error
python script.py

# Check error messages
node script.js

# View logs
tail -f logs/app.log
```

### 2. Analyze the Error
- Read error message carefully
- Check line number and stack trace
- Identify error type (SyntaxError, TypeError, etc.)
- Reproduce the bug consistently

### 3. Fix the Issue
```python
# Before (buggy)
def divide(a, b):
    return a / b

# After (fixed)
def divide(a, b):
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b
```

### 4. Test the Fix
```bash
# Run tests
pytest tests/

# Manual testing
python script.py --test
```

## Common Bug Patterns

### Python
```python
# IndexError
if index < len(list):
    item = list[index]

# KeyError
value = dictionary.get(key, default_value)

# TypeError
def func(x: int) -> int:
    if isinstance(x, str):
        x = int(x)
    return x * 2

# AttributeError
if hasattr(obj, 'attribute'):
    value = obj.attribute
```

### JavaScript
```javascript
// TypeError: Cannot read property
const value = obj?.property;

// Handle undefined
const value = obj?.property || defaultValue;

// Async/await errors
try {
    const result = await fetchData();
} catch (error) {
    console.error('Error:', error);
}
```

## Debugging Tools

### Python
```python
# Print debugging
print(f"Debug: {variable}")

# Logging
import logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# pdb
import pdb; pdb.set_trace()

# breakpoint() (Python 3.7+)
breakpoint()
```

### JavaScript
```javascript
// Console logging
console.log('Debug:', variable);
console.error('Error:', error);

// Debugger
debugger;

// Chrome DevTools
console.table(array);
console.dir(object);
```

## Error Handling Patterns

### Python
```python
def safe_divide(a, b):
    try:
        return a / b
    except ZeroDivisionError:
        return float('inf')
    except TypeError:
        return None
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise
```

### JavaScript
```javascript
function safeOperation(fn) {
    try {
        return fn();
    } catch (error) {
        console.error('Operation failed:', error);
        return null;
    }
}
```

## Code Quality Fixes

### Before
```python
def f(x):
    if x>0:
        return x*2
    else:
        return 0
```

### After
```python
def multiply_if_positive(x: int) -> int:
    """Multiply x by 2 if positive, otherwise return 0."""
    if x > 0:
        return x * 2
    return 0
```

## Performance Debugging

```python
import time

start = time.time()
# Code to measure
result = expensive_operation()
end = time.time()

print(f"Execution time: {end - start:.2f} seconds")
```

## Testing After Fix

```bash
# Unit tests
pytest test_file.py -v

# Run specific test
pytest test_file.py::test_function -v

# Coverage
pytest --cov=src tests/
```

## Best Practices
- Always understand the root cause
- Don't just patch symptoms
- Write tests to prevent regression
- Document complex fixes
- Consider edge cases
- Test in isolation
