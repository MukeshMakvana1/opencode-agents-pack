---
name: python-coding
description: Python code writing, development, AI Python, Python scripts, code execution
origin: custom-agent
---

# Python Development Skill

Use this skill when writing Python code, developing Python applications, or working with Python AI.

## When to Activate
- User asks to write Python code
- Python script development needed
- Python AI/ML development
- Python file creation or editing
- Python debugging

## Code Writing Standards

### Basic Structure
```python
"""Module docstring describing purpose."""
import os
import sys
from typing import Optional, List, Dict, Any

def main():
    """Main entry point."""
    pass

if __name__ == "__main__":
    main()
```

### Classes and OOP
```python
from dataclasses import dataclass
from typing import Optional

@dataclass
class DataClass:
    """Data class example."""
    name: str
    value: int
    optional: Optional[str] = None

class MyClass:
    def __init__(self, name: str):
        self.name = name
    
    def __str__(self) -> str:
        return f"MyClass({self.name})"
```

### Type Hints
```python
def process_data(data: List[int]) -> Dict[str, int]:
    return {"sum": sum(data), "count": len(data)}

def optional_param(name: Optional[str] = None) -> str:
    return name or "default"
```

### Error Handling
```python
try:
    result = risky_operation()
except ValueError as e:
    print(f"Value error: {e}")
except Exception as e:
    print(f"Unexpected error: {e}")
    raise
finally:
    cleanup()
```

## Python AI Development

### OpenAI Integration
```python
import os
from openai import OpenAI

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def ask_gpt(prompt: str) -> str:
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content
```

### Data Processing
```python
import pandas as pd
import numpy as np

def analyze_data(df: pd.DataFrame) -> dict:
    return {
        "mean": df.mean().to_dict(),
        "std": df.std().to_dict(),
        "shape": df.shape
    }
```

### File Operations
```python
from pathlib import Path

def read_file(path: str) -> str:
    return Path(path).read_text()

def write_file(path: str, content: str) -> None:
    Path(path).write_text(content)
```

## Running Python Code

```bash
# Run script
python script.py

# Run with arguments
python script.py --arg value

# Virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows

# Install packages
pip install package_name
pip install -r requirements.txt

# Jupyter notebook
jupyter notebook
```

## Best Practices
- Use type hints for better code quality
- Write docstrings for all functions
- Use f-strings for formatting
- Use list/dict comprehensions when appropriate
- Handle exceptions properly
- Follow PEP 8 style guide
