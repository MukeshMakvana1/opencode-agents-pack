---
name: code-execution
description: Run and execute code files, scripts, programs in multiple languages
origin: custom-agent
---

# Code Execution Skill

Use this skill when running code files, executing scripts, or running programs.

## When to Activate
- User asks to run code
- Execute Python/JS/Java scripts
- Run npm commands
- Compile and run programs
- Test code execution

## Python Execution

### Basic Run
```bash
python script.py

# With arguments
python script.py arg1 arg2

# With flags
python script.py --input file.txt --output result.txt

# Virtual environment
.\venv\Scripts\activate
python script.py
```

### pip Management
```bash
pip install package
pip install package==version
pip install -r requirements.txt
pip list
pip show package
pip uninstall package
```

## JavaScript/Node.js Execution

### Node.js
```bash
node script.js

# With arguments
node script.js arg1 arg2

# ES modules
node --experimental-modules script.mjs

# Package scripts (package.json)
npm run start
npm run dev
npm test
```

### npm Commands
```bash
npm init
npm init -y
npm install
npm install package
npm install --save-dev package
npm install -g package
npm update
npm uninstall package
```

## Java Execution

### Compile & Run
```bash
# Compile
javac Main.java

# Run
java Main

# With package
javac -d bin src/*.java
java -cp bin com.example.Main
```

### Maven/Gradle
```bash
mvn compile
mvn test
mvn package
mvn spring-boot:run

gradle build
gradle run
gradle test
```

## Web Development

### Development Servers
```bash
# Python
python -m http.server 8000
python manage.py runserver

# Node.js
npm run dev
npx serve .
npx http-server

# PHP
php -S localhost:8000
```

### Build Commands
```bash
npm run build
npm run build:css
npm run build:js

# React
npm run build

# Vue
npm run build

# Next.js
npm run build
```

## Shell/Bash Scripts

### Windows
```bash
# CMD
script.bat

# PowerShell
powershell -File script.ps1
.\script.ps1
```

### Unix/Linux/Mac
```bash
chmod +x script.sh
./script.sh

bash script.sh
sh script.sh
```

## Docker

### Container Management
```bash
docker build -t image-name .
docker run image-name
docker run -p 8000:8000 image-name
docker-compose up
docker-compose down
```

## Code Testing

### Python
```bash
pytest
pytest tests/
pytest -v
pytest --cov=src

python -m unittest
python -m pytest
```

### JavaScript
```bash
npm test
npm run test:watch
jest
mocha
```

## Process Management

### Check Running Processes
```bash
# Windows
tasklist
tasklist | findstr python

# Unix
ps aux | grep python
ps aux | grep node
```

### Kill Processes
```bash
# Windows
taskkill /IM python.exe /F
taskkill /PID 1234 /F

# Unix
pkill -f python
kill -9 PID
```

## Environment Setup

### Python Virtual Environment
```bash
python -m venv venv
.\venv\Scripts\activate  # Windows
source venv/bin/activate  # Unix
pip install -r requirements.txt
```

### Node Version Manager
```bash
nvm install node
nvm use node
nvm install 18
```

## Best Practices
- Always show command being run
- Display full output
- Handle errors gracefully
- Suggest fixes for failures
- Clean up temporary files
- Check dependencies first
- Verify environment setup
