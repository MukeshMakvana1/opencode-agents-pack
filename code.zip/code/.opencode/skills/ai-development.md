---
name: ai-development
description: AI model development, fine-tuning, machine learning, LLM integration, AI agents
origin: custom-agent
---

# AI Development Skill

Use this skill when developing AI models, fine-tuning, Python AI, or integrating LLMs.

## When to Activate
- AI model development
- Model fine-tuning
- LLM integration
- Machine learning implementation
- AI agent development
- Prompt engineering

## Python AI Setup

### Virtual Environment
```bash
python -m venv ai-env
ai-env\Scripts\activate  # Windows
source ai-env/bin/activate  # Linux/Mac
pip install torch transformers openai anthropic
```

### Environment Variables
```bash
# .env file
OPENAI_API_KEY=your-key
ANTHROPIC_API_KEY=your-key
HUGGINGFACE_TOKEN=your-token
```

## LLM Integration

### OpenAI
```python
import os
from openai import OpenAI

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def chat_with_gpt(prompt: str, model: str = "gpt-4") -> str:
    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7,
        max_tokens=1000
    )
    return response.choices[0].message.content

def chat_with_context(messages: list) -> str:
    response = client.chat.completions.create(
        model="gpt-4",
        messages=messages
    )
    return response.choices[0].message.content
```

### Anthropic Claude
```python
import anthropic

client = anthropic.Anthropic()

def ask_claude(prompt: str, max_tokens: int = 1024) -> str:
    message = client.messages.create(
        model="claude-3-opus-20240229",
        max_tokens=max_tokens,
        messages=[{"role": "user", "content": prompt}]
    )
    return message.content[0].text
```

### Hugging Face
```python
from transformers import pipeline

# Text generation
generator = pipeline("text-generation", model="gpt2")
result = generator("Once upon a time", max_length=100)

# Summarization
summarizer = pipeline("summarization")
summary = summarizer(article, max_length=150)

# Question answering
qa = pipeline("question-answering")
answer = qa(question="What is AI?", context=article)
```

## Model Fine-tuning

### Hugging Face Fine-tuning
```python
from transformers import AutoModelForSequenceClassification, AutoTokenizer, Trainer
from datasets import load_dataset

# Load data
dataset = load_dataset("csv", data_files="train.csv")

# Load model
model = AutoModelForSequenceClassification.from_pretrained("bert-base-uncased")
tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")

# Tokenize
def tokenize(batch):
    return tokenizer(batch["text"], padding=True, truncation=True)

dataset = dataset.map(tokenize, batched=True)

# Train
trainer = Trainer(
    model=model,
    train_dataset=dataset["train"],
    args=training_args
)
trainer.train()
```

### OpenAI Fine-tuning
```python
# Prepare data in OpenAI format
{"messages": [
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": "Hello"},
    {"role": "assistant", "content": "Hi! How can I help you?"}
]}

# CLI commands
openai tools fine_tunes.prepare_data -f data.jsonl
openai api fine_tunes.create -t file-xxx -m gpt-3.5-turbo
openai api fine_tunes.follow -i ft-xxx
```

## AI Agents

### Basic Agent
```python
class AIAgent:
    def __init__(self, name: str, model: str = "gpt-4"):
        self.name = name
        self.model = model
        self.memory = []
    
    def think(self, prompt: str) -> str:
        messages = [
            {"role": "system", "content": f"You are {self.name}."},
            {"role": "user", "content": prompt}
        ]
        return chat_with_gpt(messages)
    
    def remember(self, info: str):
        self.memory.append(info)
```

### Tool-using Agent
```python
class ToolAgent:
    def __init__(self):
        self.tools = {
            "search": self.web_search,
            "calculate": self.calculate,
            "code": self.execute_code
        }
    
    def execute(self, task: str) -> str:
        # Parse task and select tool
        tool, args = self.parse_task(task)
        return self.tools[tool](args)
```

## Prompt Engineering

### Few-shot Prompting
```python
prompt = """Classify sentiment as positive, negative, or neutral.

Example 1: "I love this product!" -> Positive
Example 2: "This is okay." -> Neutral
Example 3: "Terrible experience." -> Negative

Task: "{user_input}" ->
"""
```

### Chain of Thought
```python
prompt = """Solve this problem step by step:

Problem: If there are 5 birds on a tree and I shoot 2, how many remain?

Let's think through this:
1. Start with 5 birds
2. Shoot 2 birds
3. The remaining birds will fly away due to the noise
4. Answer: 0 birds remain
"""
```

## RAG (Retrieval-Augmented Generation)

```python
from langchain.document_loaders import TextLoader
from langchain.vectorstores import Chroma
from langchain.llms import OpenAI
from langchain.chains import RetrievalQA

# Load documents
loader = TextLoader("documents.txt")
documents = loader.load()

# Create vector store
vectorstore = Chroma.from_documents(documents, embedding=OpenAIEmbeddings())

# Create QA chain
qa = RetrievalQA.from_chain_type(
    llm=OpenAI(),
    chain_type="stuff",
    retriever=vectorstore.as_retriever()
)

# Query
result = qa.run("What is mentioned in the documents?")
```

## Best Practices
- Use environment variables for API keys
- Implement proper error handling
- Add rate limiting for API calls
- Cache responses when possible
- Monitor costs and usage
- Log all API calls
- Handle timeouts gracefully
