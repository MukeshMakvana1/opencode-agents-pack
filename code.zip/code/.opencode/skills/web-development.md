---
name: web-development
description: HTML, CSS, JavaScript, Node.js, npm web development
origin: custom-agent
---

# Web Development Skill

Use this skill when creating websites, web applications, or working with frontend/backend technologies.

## When to Activate
- Writing HTML, CSS, JavaScript
- Node.js development
- npm package management
- Frontend/backend development
- Web application creation

## HTML

### Basic Structure
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Title</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>Navigation</nav>
    </header>
    <main>
        <h1>Heading</h1>
        <p>Content</p>
    </main>
    <footer>Footer</footer>
    <script src="script.js"></script>
</body>
</html>
```

### Semantic HTML
```html
<article>
    <header>
        <h2>Article Title</h2>
        <time datetime="2024-01-01">January 1, 2024</time>
    </header>
    <section>
        <p>Content section</p>
    </section>
    <footer>
        <address>Contact info</address>
    </footer>
</article>
```

## CSS

### Responsive Design
```css
.container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 1rem;
    padding: 1rem;
}

@media (max-width: 768px) {
    .container {
        grid-template-columns: 1fr;
    }
}
```

### Flexbox
```css
.navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem;
}

.card {
    flex: 1;
    min-width: 250px;
    padding: 1.5rem;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}
```

### CSS Variables
```css
:root {
    --primary-color: #007bff;
    --secondary-color: #6c757d;
    --spacing: 1rem;
}

.button {
    background-color: var(--primary-color);
    padding: var(--spacing);
}
```

## JavaScript

### Modern ES6+
```javascript
const fetchData = async (url) => {
    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error('Network error');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
};

// Destructuring
const { name, age } = userData;

// Spread operator
const newArray = [...oldArray, newItem];
```

### DOM Manipulation
```javascript
const element = document.querySelector('.class');
element.addEventListener('click', () => {
    element.classList.toggle('active');
});

// Create element
const div = document.createElement('div');
div.textContent = 'New content';
document.body.appendChild(div);
```

### Classes
```javascript
class App {
    constructor(name) {
        this.name = name;
    }
    
    greet() {
        return `Hello, ${this.name}!`;
    }
}

const app = new App('World');
```

## Node.js

### Package.json Setup
```bash
npm init -y
npm install package_name
npm install --save-dev dev_package
```

### File System
```javascript
const fs = require('fs').promises;

async function readFile(path) {
    const data = await fs.readFile(path, 'utf8');
    return data;
}

async function writeFile(path, content) {
    await fs.writeFile(path, content, 'utf8');
}
```

### HTTP Server
```javascript
const http = require('http');

const server = http.createServer((req, res) => {
    res.writeHead(200, {'Content-Type': 'text/plain'});
    res.end('Hello World');
});

server.listen(3000, () => {
    console.log('Server running on port 3000');
});
```

### Express.js
```javascript
const express = require('express');
const app = express();

app.get('/api/data', (req, res) => {
    res.json({ message: 'Hello' });
});

app.listen(3000);
```

## npm Commands
```bash
npm init -y              # Initialize project
npm install               # Install dependencies
npm install package       # Install package
npm run dev              # Run dev server
npm run build            # Build for production
npm test                 # Run tests
npm install -g package    # Global install
```

## Best Practices
- Use semantic HTML
- Mobile-first responsive design
- Modern CSS (Flexbox, Grid)
- ES6+ JavaScript
- Error handling
- Performance optimization
- Accessibility (ARIA, alt text)
