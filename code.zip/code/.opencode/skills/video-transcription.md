---
name: video-transcription
description: YouTube video transcription, video summarization, video content extraction
origin: custom-agent
---

# Video Transcription Skill

Use this skill when transcribing YouTube videos, generating summaries, or extracting content from video URLs.

## When to Activate
- User provides YouTube video link
- Need to transcribe video content
- Generate video summary
- Extract key points from video
- Convert video to text

## Transcription Process

### 1. Receive Video URL
```python
def extract_video_id(url: str) -> str:
    """Extract YouTube video ID from URL."""
    import re
    patterns = [
        r'(?:v=|\/)([0-9A-Za-z_-]{11}).*',
        r'(?:embed\/)([0-9A-Za-z_-]{11})',
        r'(?:watch\?v=)([0-9A-Za-z_-]{11})'
    ]
    for pattern in patterns:
        match = re.match(pattern, url)
        if match:
            return match.group(1)
    return None
```

### 2. Using youtube-transcript-api
```python
from youtube_transcript_api import YouTubeTranscriptApi

def get_transcript(video_id: str) -> str:
    """Get transcript for a YouTube video."""
    try:
        transcript = YouTubeTranscriptApi.get_transcript(video_id)
        text = ' '.join([item['text'] for item in transcript])
        return text
    except Exception as e:
        print(f"Error: {e}")
        return None

# With timestamps
def get_transcript_with_timestamps(video_id: str) -> list:
    transcript = YouTubeTranscriptApi.get_transcript(video_id)
    return [(item['start'], item['text']) for item in transcript]
```

### 3. Alternative: yt-dlp
```bash
# Download transcript
yt-dlp --write-auto-sub --skip-download "VIDEO_URL"

# Download specific language
yt-dlp --write-auto-sub --sub-lang en --skip-download "VIDEO_URL"
```

## Summarization

### Basic Summary
```python
def summarize_text(text: str, max_length: int = 200) -> str:
    """Create a basic summary of text."""
    sentences = text.split('. ')
    if len(sentences) <= 5:
        return text
    
    # Take first and last sentences, plus key sentences
    summary = [sentences[0]]
    summary.append(sentences[len(sentences)//2])
    summary.append(sentences[-1])
    
    return '. '.join(summary) + '.'
```

### AI-Powered Summary
```python
import os
from openai import OpenAI

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def summarize_with_ai(transcript: str) -> str:
    """Use AI to summarize video transcript."""
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are a video summarizer. Create a concise summary."},
            {"role": "user", "content": f"Summarize this video transcript:\n\n{transcript[:4000]}"}
        ]
    )
    return response.choices[0].message.content
```

## Output Formats

### Plain Text
```
Video Title: Example Video
Duration: 10:30
Transcription:

Hello everyone, today we're going to discuss...
[Full transcription text]
```

### Timestamped
```
[00:00] Hello everyone, welcome to the video
[00:15] Today we'll cover topic X
[00:30] Let's start with the basics...
```

### Summary with Key Points
```
## Summary
This video covers [main topic] and discusses [key points].

## Key Points
1. First important point
2. Second important point
3. Third important point

## Timestamps
- 00:00 - Introduction
- 02:30 - Main topic begins
- 05:00 - Practical examples
- 08:00 - Conclusion
```

## Working with OpenCode

### Web Fetch
```
Use web-fetch tool with:
- URL: YouTube video URL
- Format: markdown or text

Then process the content to extract transcript.
```

## Best Practices
- Always verify video availability
- Handle unavailable transcripts gracefully
- Provide timestamps for navigation
- Create both short and detailed summaries
- Include key topics and takeaways

## Error Handling

```python
def safe_transcribe(video_url: str) -> dict:
    """Safely transcribe a video with error handling."""
    try:
        video_id = extract_video_id(video_url)
        transcript = get_transcript(video_id)
        summary = summarize_text(transcript)
        
        return {
            "success": True,
            "video_id": video_id,
            "transcript": transcript,
            "summary": summary
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }
```
